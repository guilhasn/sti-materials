﻿using EI.SI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class Server
    {

        public static List<ClientHandler> clients = new List<ClientHandler>();
        public static readonly object lockObj = new object(); // Para sincronização

        private const int PORT = 10000;
        private static int clientcounter = 0;

        
        static void Main(string[] args)
        {
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Any, PORT);
            TcpListener listener = new TcpListener(endpoint);

            listener.Start();
            Console.WriteLine("SERVER READY");
            int clientCounter = 0;

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                clientCounter++;
                Console.WriteLine("Client {0} connected", clientCounter);
                ClientHandler clientHandler = new ClientHandler(client, clientCounter);

                lock (lockObj)
                {
                    clients.Add(clientHandler);
                }
                                

                clientHandler.Handle();
            }
        }
    }

    class ClientHandler
    {
        private AESCrypto aes;
        private TcpClient client;
        private int clientID;
        // Criar instância do AESCrypto com os mesmos parâmetros do cliente
        public ClientHandler(TcpClient client, int clientID)
        {
            this.client = client;
            this.clientID = clientID;
            aes = new AESCrypto("segredo123", "iv123");
        }
        public void Handle()
        {
            Thread thread = new Thread(threadHandler);
            thread.Start();
        }
        private void threadHandler()
        {
            NetworkStream networkStream = this.client.GetStream();
            ProtocolSI protocolSI = new ProtocolSI();
            


            while (protocolSI.GetCmdType() != ProtocolSICmdType.EOT)
            {
                int bytesRead = networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                byte[] ack;
                                   
                switch (protocolSI.GetCmdType())
                {
                    case ProtocolSICmdType.DATA:
                        //Console.WriteLine("Client " + clientID + ": " + protocolSI.GetStringFromData());
                        //ack = protocolSI.Make(ProtocolSICmdType.ACK);
                        ////byte[] ack = Encoding.UTF8.GetBytes("OK");
                        //networkStream.Write(ack, 0, ack.Length);
                        //break;
                        
                        string received = protocolSI.GetStringFromData();
                        Console.WriteLine("Client " + clientID + ": " + received);

                        // Decrypt the message
                        string msgDecifrada = aes.Decrypt(received);


                        // Enviar ACK
                        ack = protocolSI.Make(ProtocolSICmdType.ACK);
                        networkStream.Write(ack, 0, ack.Length);

                        // Enviar resposta de volta ao cliente
                        // string response = "Mensagem recebida: " + received;
                        // byte[] responsePacket = protocolSI.Make(ProtocolSICmdType.DATA, response);
                        // networkStream.Write(responsePacket, 0, responsePacket.Length);

                        // Enviar mensagem para todos os outros clientes
                        lock (Server.lockObj)
                        {
                            foreach (var handler in Server.clients)
                            {
                                if (handler != this)
                                {
                                    handler.SendMessage("Cliente " + clientID + ": " + received);
                                }
                            }
                        }





                        break;





                    case ProtocolSICmdType.EOT:
                        Console.WriteLine("Ending Thread from Client {0}", clientID);
                        ack = protocolSI.Make(ProtocolSICmdType.ACK);
                        networkStream.Write(ack, 0, ack.Length);
                        break;
                }
            }

            networkStream.Close();
            client.Close();
        }


        public void SendMessage(string msg)
        {
            try
            {
                ProtocolSI protocolSI = new ProtocolSI();
                NetworkStream ns = client.GetStream();
                byte[] packet = protocolSI.Make(ProtocolSICmdType.DATA, msg);
                ns.Write(packet, 0, packet.Length);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao enviar para cliente " + clientID + ": " + ex.Message);
            }
        }
    }
}