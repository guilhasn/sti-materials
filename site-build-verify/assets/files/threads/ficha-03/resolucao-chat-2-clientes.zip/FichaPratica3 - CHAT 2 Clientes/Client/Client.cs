﻿using EI.SI;
using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;


namespace Client
{
    public partial class Client : Form
    {
        private const int PORT = 10000;
        NetworkStream networkStream;
        ProtocolSI protocolSI;
        TcpClient client;

        private AESCrypto aes;

        public Client()
        {
            InitializeComponent();
            IPEndPoint endpoint = new IPEndPoint(IPAddress.Loopback, PORT);
            client = new TcpClient();
            client.Connect(endpoint);
            networkStream = client.GetStream();
            protocolSI = new ProtocolSI();
           // Task.Run(() => ListenForMessages());

        }

     /*   private void ListenForMessages()
        {
            try
            {
                while (true)
                {
                    networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);

                    if (protocolSI.GetCmdType() == ProtocolSICmdType.DATA)
                    {
                        string msg = protocolSI.GetStringFromData();

                        // Atualiza o tbChat de forma segura
                        Invoke((MethodInvoker)(() =>
                        {
                            tbChat.AppendText(msg + Environment.NewLine);
                        }));
                    }
                }
            }
            catch (Exception ex)
            {
                Invoke((MethodInvoker)(() =>
                {
                    tbChat.AppendText("Erro na escuta: " + ex.Message + Environment.NewLine);
                }));
            }
        }*/



        private void buttonSend_Click(object sender, EventArgs e)
        {
            string msg = textBoxMessage.Text;
            textBoxMessage.Clear();

            tbChat.AppendText("Tu: " + msg + Environment.NewLine);


            aes = new AESCrypto("segredo123", "iv123");
            string mensagemCifrada = aes.Encrypt(msg);


            //enviar mensagem
            byte[] packet = protocolSI.Make(ProtocolSICmdType.DATA, mensagemCifrada);
            networkStream.Write(packet, 0, packet.Length);



            // while (protocolSI.GetCmdType() != ProtocolSICmdType.ACK)
            // {
            //    networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
            // }
            // Esperar pelo ACK
            ProtocolSICmdType cmd;
            do
            {
                networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
                cmd = protocolSI.GetCmdType();
            } while (cmd != ProtocolSICmdType.ACK);

            // Esperar por mensagem de resposta (DATA)
            // Tenta receber uma resposta (como um eco ou mensagem de outro cliente)
            networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
            if (protocolSI.GetCmdType() == ProtocolSICmdType.DATA)
            {
                string response = protocolSI.GetStringFromData();
                tbChat.AppendText("Servidor: " + response + Environment.NewLine);
            }



        }
        
        private void CloseClient()
        {
            byte[] eot = protocolSI.Make(ProtocolSICmdType.EOT);
            networkStream.Write(eot, 0, eot.Length);
            networkStream.Read(protocolSI.Buffer, 0, protocolSI.Buffer.Length);
            networkStream.Close();
            client.Close();
        }
                        //Exit
        private void buttonQuit_Click(object sender, EventArgs e)
        {
            CloseClient();
            this.Close();
        }


        private void Client_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseClient();
        }
    }
}
