﻿namespace Criptografia
{
    public class Class1
    {

    }
}
