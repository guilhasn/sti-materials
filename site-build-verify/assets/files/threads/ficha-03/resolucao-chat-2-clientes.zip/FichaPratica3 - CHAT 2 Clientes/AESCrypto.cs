﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public class AESCrypto
{
    private AesCryptoServiceProvider aes;

    public AESCrypto(string passKey, string passIV)
    {
        byte[] saltKey = new byte[] { 0, 1, 0, 8, 2, 9, 9, 7 };
        byte[] saltIV = new byte[] { 7, 8, 7, 8, 2, 5, 9, 5 };

        Rfc2898DeriveBytes keyGen = new Rfc2898DeriveBytes(passKey, saltKey, 1000);
        Rfc2898DeriveBytes ivGen = new Rfc2898DeriveBytes(passIV, saltIV, 1000);

        aes = new AesCryptoServiceProvider();
        aes.Key = keyGen.GetBytes(16);
        aes.IV = ivGen.GetBytes(16);
    }

    public string Encrypt(string plainText)
    {
        byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
        MemoryStream ms = new MemoryStream();
        CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
        cs.Write(plainBytes, 0, plainBytes.Length);
        cs.Close();
        return Convert.ToBase64String(ms.ToArray());
    }

    public string Decrypt(string encryptedText)
    {
        byte[] encryptedBytes = Convert.FromBase64String(encryptedText);
        MemoryStream ms = new MemoryStream(encryptedBytes);
        CryptoStream cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read);
        byte[] decrypted = new byte[ms.Length];
        int bytesRead = cs.Read(decrypted, 0, decrypted.Length);
        cs.Close();
        return Encoding.UTF8.GetString(decrypted, 0, bytesRead);
    }
}

